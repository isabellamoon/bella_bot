@echo off
chcp 65001 >nul
setlocal
title bella_cert - 버추얼 벨라 신뢰 등록
set "VBF=%~f0"
net session >nul 2>&1
if errorlevel 1 (
  echo 관리자 권한으로 다시 실행합니다...
  powershell -NoProfile -Command "Start-Process -FilePath $env:VBF -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:VBF,[Text.Encoding]::UTF8); $i=$s.IndexOf('#'+'==PS=='); iex $s.Substring($i)"
exit /b
#==PS==
# bella_cert : 버추얼 벨라 신뢰 등록 / 해제 (이 PC 전용)
# [1] 등록: 이 PC 전용 '코드 서명 전용' 인증서를 새로 만들어 VirtualBella.exe 에 서명하고,
#     인증서 공개 부분을 이 PC 신뢰 목록에 넣은 뒤, 서명 키는 바로 지운다.
#     -> 이후 이 인증서로는 아무것도 새로 서명할 수 없다.
# [2] 해제: 위에서 넣은 인증서를 이 PC에서 모두 지운다.
# [3] 상태: 등록 여부와 VirtualBella.exe 서명 상태를 보여준다.
$subj = 'CN=VirtualBella (this PC only)'
$dir  = Split-Path -Parent $env:VBF
$exe  = Join-Path $dir 'VirtualBella.exe'
$stores = 'Cert:\LocalMachine\Root', 'Cert:\LocalMachine\TrustedPublisher', 'Cert:\CurrentUser\My'

function Find-Bella { foreach ($loc in $stores) { Get-ChildItem $loc | Where-Object { $_.Subject -eq $subj } } }

function Remove-Bella {
  $n = 0
  foreach ($c in @(Find-Bella)) {
    Remove-Item $c.PSPath -DeleteKey -ErrorAction SilentlyContinue
    if (Test-Path $c.PSPath) { Remove-Item $c.PSPath -ErrorAction SilentlyContinue }
    $n++
  }
  $n
}

function Do-Install {
  $ErrorActionPreference = 'Stop'
  try {
    if (-not (Test-Path $exe)) { throw "bella_cert 와 같은 폴더에 VirtualBella.exe 가 없어요. ($dir)" }
    Get-Process VirtualBella -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Milliseconds 500

    Write-Host '1/5 이전에 등록한 벨라 인증서 정리'
    [void](Remove-Bella)

    Write-Host '2/5 이 PC 전용 인증서 만들기 (코드 서명 전용)'
    $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject $subj `
      -CertStoreLocation 'Cert:\CurrentUser\My' -KeyExportPolicy NonExportable `
      -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -NotAfter (Get-Date).AddYears(10)

    Write-Host '3/5 이 PC의 신뢰 목록에 등록'
    $cer = Join-Path $env:TEMP ("vb-" + $cert.Thumbprint + ".cer")
    Export-Certificate -Cert $cert -FilePath $cer | Out-Null
    Import-Certificate -FilePath $cer -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null
    Import-Certificate -FilePath $cer -CertStoreLocation 'Cert:\LocalMachine\TrustedPublisher' | Out-Null
    Remove-Item $cer

    Write-Host '4/5 VirtualBella.exe 서명'
    Unblock-File $exe
    [void](Set-AuthenticodeSignature -FilePath $exe -Certificate $cert -HashAlgorithm SHA256)
    $v = Get-AuthenticodeSignature $exe
    if ($v.Status -ne 'Valid') { throw "서명 확인 실패: $($v.Status) $($v.StatusMessage)" }

    Write-Host '5/5 서명 키 삭제 (이제 이 인증서로는 새 서명 불가)'
    Remove-Item ("Cert:\CurrentUser\My\" + $cert.Thumbprint) -DeleteKey

    Write-Host ''
    Write-Host '완료! 버추얼 벨라를 실행합니다.' -ForegroundColor Green
    Write-Host '다음부터는 VirtualBella.exe 만 실행하면 돼요. 새 버전 exe 로 바꾸면 [1]을 한 번 더 해 주세요.'
    Start-Process $exe -WorkingDirectory $dir
    return $true
  } catch {
    Write-Host ''
    Write-Host ("실패: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host '일부만 바뀌었을 수 있어요. [2] 해제로 되돌릴 수 있어요.'
    return $false
  }
}

function Do-Remove {
  $n = Remove-Bella
  if ($n -gt 0) { Write-Host "벨라 인증서 $n 개를 지웠어요. 이 PC는 등록 전 상태로 돌아갔어요." -ForegroundColor Green }
  else { Write-Host '지울 벨라 인증서가 없어요. 이미 등록 전 상태예요.' }
  Write-Host 'VirtualBella.exe 는 그대로 있어요. 필요 없으면 폴더째 지우시면 돼요.'
}

function Do-Status {
  $root = @(Get-ChildItem 'Cert:\LocalMachine\Root' | Where-Object { $_.Subject -eq $subj }).Count
  $pub  = @(Get-ChildItem 'Cert:\LocalMachine\TrustedPublisher' | Where-Object { $_.Subject -eq $subj }).Count
  $key  = @(Get-ChildItem 'Cert:\CurrentUser\My' | Where-Object { $_.Subject -eq $subj -and $_.HasPrivateKey }).Count
  Write-Host ("신뢰 목록 등록: " + $(if ($root -and $pub) { '예' } else { '아니오' }))
  Write-Host ("남아 있는 서명 키: " + $key + " 개 (0 이어야 정상)")
  if (Test-Path $exe) {
    $v = Get-AuthenticodeSignature $exe
    Write-Host ("VirtualBella.exe 서명: " + $(if ($v.Status -eq 'Valid') { '정상' } elseif ($v.Status -eq 'NotSigned') { '서명 안 됨 ([1] 필요)' } else { "$($v.Status) ([1] 다시 필요)" }))
  } else { Write-Host "VirtualBella.exe: 이 폴더에 없음 ($dir)" }
}

while ($true) {
  Write-Host ''
  Write-Host '=============================================='
  Write-Host '  bella_cert  ·  버추얼 벨라 신뢰 등록 (이 PC 전용)'
  Write-Host '=============================================='
  Write-Host '  [1] 신뢰 등록 + 벨라 실행'
  Write-Host '  [2] 신뢰 해제 (등록 전으로 되돌리기)'
  Write-Host '  [3] 상태 확인'
  Write-Host '  [0] 닫기'
  Write-Host ''
  $k = Read-Host '번호를 눌러 Enter'
  Write-Host ''
  switch ($k.Trim()) {
    '1' { if (Do-Install) { Start-Sleep -Seconds 3; return } }
    '2' { Do-Remove }
    '3' { Do-Status }
    '0' { return }
    default { Write-Host '1, 2, 3, 0 중에서 골라 주세요.' }
  }
}
